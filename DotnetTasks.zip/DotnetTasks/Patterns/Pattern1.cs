﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Patterns
{
    class Pattern1
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter a number:");
            num = int.Parse(Console.ReadLine());
            for (int row = 1; row <= num; row++)
            {
                for (int col = 1; col <= row; col++)
                {
                    Console.Write($"{col}\t");
                }
                Console.WriteLine();
            }
        }
    }
}
