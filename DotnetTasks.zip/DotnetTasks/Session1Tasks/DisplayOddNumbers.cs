﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Session1Tasks
{
    class DisplayOddNumbers
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            int num;
            Console.WriteLine("Enter a number:");
            num = int.Parse(Console.ReadLine());
            int max = num;
            int min = 1;
            while (min <= max)
            {
                Console.Write(min);
                min = min + 2;
            }
        }
    }
}
