﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Session1Tasks
{
    class EvenNumbers
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ssjc");
        }
    }
}
