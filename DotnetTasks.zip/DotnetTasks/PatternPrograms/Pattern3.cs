﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PatternPrograms
{
    class Pattern3
    {
        static void Main(string[] args)
        {
            int num;
            int add = 1;
            Console.WriteLine("Enter a number:");
            num = int.Parse(Console.ReadLine());
            for (int row = 1; row <= num; row++)
            {
                for (int col = 1; col <= row; col++)
                {
                    Console.Write($"{add++}\t");
                }
                Console.WriteLine();
            }
        }
    }
}
