﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class Multiplynumber
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter a number");
            num = int.Parse(Console.ReadLine());
            //for (int i = 1; i <=num ; i++)
            //{
            //    Console.WriteLine($"{i}");
            //}
            for (int i = 1; i <= num; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    Console.WriteLine($"{i} * {j} = {i*j}");
                }              
            }
        }
    }
}
