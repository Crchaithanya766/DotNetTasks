﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class Palindrome
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter a number");
            num = int.Parse(Console.ReadLine());
            if(num <= 0 || num == 0)
            {
                Console.WriteLine($" {num} Zero or negative returns -1");
            }
            else if(num < 100 || num >999)
            {
                Console.WriteLine($" {num} three digit number returns -2");
            }
            else if(num/100 == num % 10)
            {
                Console.WriteLine($"{num} Palindrome returns 1");
            }
            else if(num <100 ||num <999)
            {
                Console.WriteLine($"{num} is not a Palindrome returns 1");
            }


           // int num;
           // int temp;           
           // int revnum = 0;
           // int rem;           
           // Console.WriteLine("Enter a Number:");
           // num = int.Parse(Console.ReadLine());
           // temp = num;

           //while(num > 0)
           // {
           //     rem = num % 10;   //remainder by dividing with 10 
           //     revnum = revnum * 10 + rem; //multiplying the revnum with 10 and adding remainder
           //     num = num / 10;       //quotient by dividing with 10   
           // }
           // Console.WriteLine($"The Reversed Number is: {revnum}");
           // if (revnum == temp)
           // {
           //     Console.WriteLine($"Number is Palindrome");
           // }
           // else
           //     Console.WriteLine($"Number is Not a Palindrome");


                
        }
    }
}
