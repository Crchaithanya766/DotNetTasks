﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class MultipleOf100
    {
        static void Main(string[] args)
        {
            int num;
          
            int mul = 0;
            Console.WriteLine("Enter a number");
            num = int.Parse(Console.ReadLine());
           
            if (num > 0)
            {
                
                    mul = (((num / 100) + 1) * 100);
                    
                    
                
                Console.WriteLine($"Multiple of odd number: {mul}");
            }
            else
                Console.WriteLine($" {num} is an even number");
        }

        //while(num >0 && max >=min)
        //{
        //    int mul1 = min * num;
        //    Console.WriteLine($"{mul1}");
        //}


    }
}