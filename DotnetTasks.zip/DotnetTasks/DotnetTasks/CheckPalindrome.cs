﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class CheckPalindrome
    {
        public static bool IsPalindrome(int num)
        {                               
            return num == Reverse(num);          
        }

        private static int Reverse(int num)
        {
            int rev = 0;
            while (num > 0)
            {
                rev = rev * 10 + num % 10;
                num /= 10;
            }
            return rev;
        }
        static void Main(string[] args)
        {
            //if (num > 0 && num < 9)
            //{
            //    Console.WriteLine("-2");
            //}
            //else if (num <= 0)
            //{
            //    Console.WriteLine("-1");
            //}
            Console.WriteLine(Reverse(123));
            Console.WriteLine(IsPalindrome(2332));
            Console.WriteLine(IsPalindrome(121));
        }
    }
}
