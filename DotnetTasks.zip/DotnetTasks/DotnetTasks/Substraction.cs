﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class Substraction
    {
        static void Main(string[] args)
        {
            //int mod = 0;
            //int remainer = 0;
            int num;
            int sub;
            Console.WriteLine("Enter a Number:");
            num = int.Parse(Console.ReadLine());

            if (num > 10 && num < 99)
            {
                int mod = num % 10;
                int remainer = num / 10;
                sub = remainer - mod;

                Console.WriteLine($" difference of it's digits: {sub}");
            }
           
            if (num < 0)
            {
                Console.WriteLine("-3");
            }
            if (num > 99)
            {
                Console.WriteLine("-2");
            }
            if (num > 0 && num < 9)
            {
                Console.WriteLine("it returns -1");
            }

        }
    }
}
