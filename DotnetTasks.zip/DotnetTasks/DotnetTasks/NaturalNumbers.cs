﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class NaturalNumbers
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first number:");
            int frst = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter second number:");
            int secn = int.Parse(Console.ReadLine());
            PrintNatural(frst, secn);
        }

        public static int PrintNatural(int frst, int secn)
        {
            if (frst <= secn)
            {
                Console.Write(frst + " ");
                frst++;
                PrintNatural(frst, secn);
            }
            else if (frst < 0 || secn < 0)
            {
                Console.WriteLine("-1");
            }
            else if (frst == 0 || secn == 0)
            {
                Console.WriteLine("-2");
            }
            return frst;
           
        }
    }
}
