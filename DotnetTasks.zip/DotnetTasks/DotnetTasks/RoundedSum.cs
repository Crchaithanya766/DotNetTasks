﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class RoundedSum
    {
        static void Main(string[] args)
        {      
                Console.WriteLine("Enter a num1");
                int num1 = int.Parse(Console.ReadLine());
                Console.WriteLine("enter a num2");
                int num2 = int.Parse(Console.ReadLine());
                Console.WriteLine("enter a num3");
                int num3 = int.Parse(Console.ReadLine());

                int mul1 = 0;
                int mul2 = 0;
                int mul3 = 0;




                if (num1 <= 0 || num2 <= 0 || num3 <= 0)
                {
                    Console.WriteLine("-1");
                }



                else if (num1 != 0)
                {
                    if (num1 > 0)
                    {
                        int digit = num1 % 10;



                        if (digit > 5)
                        {
                            mul1 = ((num1 / 10) + 1) * 10;
                        }
                        else
                        {
                            mul1 = (((num1 / 10) + 1) * 10) - 10;
                        }
                        Console.WriteLine($" multiple of {num1} is: {mul1}");
                    }

                    if (num2 > 0)
                    {
                        int digit = num2 % 10;
                        if (digit > 5)
                        {
                            mul2 = ((num2 / 10) + 1) * 10;
                        }
                        else
                        {
                            mul2 = (((num2 / 10) + 1) * 10) - 10;
                        }
                        Console.WriteLine($" multiple of {num2} is: {mul2}");
                    }
                    if (num3 > 0)
                    {
                        int digit = num3 % 10;
                        if (digit > 5)
                        {
                            mul3 = ((num3 / 10) + 1) * 10;
                        }
                        else
                        {
                            mul3 = (((num3 / 10) + 1) * 10) - 10;
                        }
                        Console.WriteLine($" multiple of {num3} is: {mul3}");
                        Console.WriteLine();
                        Console.WriteLine($"The sum of mul value is: {mul1} + {mul2} + {mul3} = {mul1 + mul2 + mul3}");
                    }



                }
            }
        }
    }