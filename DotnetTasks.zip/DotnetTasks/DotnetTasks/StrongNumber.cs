﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class StrongNumber
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter a number");
            num = int.Parse(Console.ReadLine());
            int copy = num;
            int sum = 0;            
            while (num > 0)
            {
                int digit = num % 10; //5
                int fact = 1;
                int min = 1;
                while (min <= digit) //(5<=5)
                {
                    fact = fact * min; //1 2 6 24 120
                    min++;
                }
                sum = sum + fact;//120 144 145
                num = num / 10; //14 1 0
            }
            if (copy == sum)
            {
                Console.WriteLine($"{copy} is strong number");
            }
            else
            {
                Console.WriteLine($"{copy}");
            }
        }
    }
}
