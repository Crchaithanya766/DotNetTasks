﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class CheckArmStrong
    {

        public static bool IsArmstrong(int num)
        {
            int copy = num;
            int sum = 0;
            int pow = CountDigits(num);
            while(num > 0)
            {
                int digit = num % 10;
                sum = sum + Power(digit, pow);
                num = num / 10;
            }
            return copy == sum;
        }

        private static int CountDigits(int num)
        {
            int count = 0;
            while( num > 0)
            {
                int digit = num % 10;
                count++;
                num /= 10;
            }
            return count;
        }

        private static int Power(int digit, int pow)
        {
            int res = 1;
            for(int i=1; i<=pow;i++)
            {
                res = res * digit;
            }
            return res;
        }

        static void Main(string[] args)
        {
            Console.WriteLine(IsArmstrong(153));
        }
    }
}
