﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class GratestNumber
    {
        static void Main(string[] args)
        {
            int num1;
            int num2;            
            Console.WriteLine("Enter number 1:");
            num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter number 2:");
            num2 = int.Parse(Console.ReadLine());

            int gratestno = num1;

            if (num1 < 0 || num2 < 0)
            {
                Console.WriteLine("-1");
            }
            else if (num1 == 0 || num2 == 0)
            {
                Console.WriteLine("-2");
            }
            else if(gratestno < num2)
            {
                gratestno = num2;
                Console.WriteLine($"Gratest number is:{gratestno}");
            }
                     
        }
        }
}
