﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class Factorial
    {
        
        static void Main(string[] args)
        {
            int num;
            int min = 1;
            int fact = 1;
            int max;           
            Console.WriteLine("Enter a number");
            num = int.Parse(Console.ReadLine());
            max = num;
            while(min <=max)
            {
                fact = fact * min; //1 2 6 24 120
                min++;
            }
            Console.WriteLine($"The Factorial of a given number is:{fact}");
        }
    }
}
