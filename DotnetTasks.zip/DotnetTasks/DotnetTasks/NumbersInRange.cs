﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class NumbersInRange
    {
        static void Main(string[] args)
        {           
                Console.WriteLine("Enter first number:");
                int frstNumber = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter second number:");
                int secondNumber = int.Parse(Console.ReadLine());
                PrintNatural(frstNumber, secondNumber);
            }

            public static int PrintNatural(int frstNumber, int secondNumber)
            {
               if (frstNumber < secondNumber)
            {
                Console.Write(frstNumber + 1 + " ");
                frstNumber++;
                //Console.Write(secondNumber - 1 + " ");
                secondNumber--;
                PrintNatural(frstNumber, secondNumber);                
            }
            else if (frstNumber < 0 || secondNumber < 0)
                {
                    Console.WriteLine("-1");
                }
                else if (frstNumber  == secondNumber)
                {
                    Console.WriteLine("-2");
                }
                else if(frstNumber > secondNumber)
                {
                Console.WriteLine("-3");
                }
                return frstNumber;

            }
        }
    }
