﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class SumOfMul10
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a num1");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a num2");
            int num2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter a num3");
            int num3 = int.Parse(Console.ReadLine());

            int mul1 = 0;
            int mul2 = 0;
            int mul3 = 0;
            if (num1 <= 0 || num2 <= 0 || num3 <= 0)
            {
                Console.WriteLine("-1");
            }
            else if (num1 % 2 == 0)
            {
                if (num1 > 0)
                {
                    for (int i = num1; i <= 10; i++)
                    {
                        mul1 = num1 * i;
                    }
                    Console.WriteLine($" multiple of {num1} is: {mul1}");
                }
                if (num2 > 0)
                {
                    for (int i = num2; i <= 10; i++)
                    {
                        mul2 = num2 * i;
                    }
                    Console.WriteLine($" multiple of {num2} is: {mul2}");
                }
                if (num3 > 0)
                {
                    for (int i = num3; i <= 10; i++)
                    {
                        mul3 = num3 * i;
                    }
                    Console.WriteLine($" multiple of {num3} is: {mul3}");
                }
                Console.WriteLine();
                Console.WriteLine($"The sum of mul value is: {mul1} + {mul2} + {mul3} = {mul1 + mul2 + mul3}");
            }
            if (num1 % 2 != 0 || num2 % 2 != 0 || num3 % 2 != 0)
            {
                int val1 = num1 * num1 * num1;
                int val2 = num2 * num2 * num2;
                int val3 = num3 * num3 * num3;
                Console.WriteLine($"The {num1} cube value is : {val1}\n The {num2} cube value is : {val2}\n The {num3} cube value is : {val3}");
            }
        }
        //int cub;
        //Console.WriteLine("Enter a Number (a)");
        //int num1 = int.Parse(Console.ReadLine());
        ////Console.WriteLine("Enter a Number (b)");
        ////int num2 = int.Parse(Console.ReadLine());
        ////Console.WriteLine("Enter a Number (c)");
        ////int num3 = int.Parse(Console.ReadLine());
        //int mul = num1 * 10;
        //if (num1 <= 0)
        //{
        //    Console.WriteLine("-1"); //the given number  is negative or zero, return -1.
        //}

        //else if (mul % 2! == 0)
        //{
        //    cub = num1 * num1 * num1;
        //    Console.WriteLine($"odd number: {cub}"); //given number is odd, return cube of the given number.
        //}
    }
    }
