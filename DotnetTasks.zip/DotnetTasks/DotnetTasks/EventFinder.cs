﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class EventFinder
    {
        static void Main(string[] args)
        {
           
            int num;
            Console.WriteLine("Enter a Number:");
            num = int.Parse(Console.ReadLine());

            if (num % 2 == 0) //num=22,35
            {
                Console.WriteLine($" The number is an even number:returns 0"); //return 0;
            }
            else
            {
                Console.WriteLine($" The number is an odd number:returns 1"); //return 1;
            }
            if (num < 0 )
            {
                Console.WriteLine("-1");
            }          

        }

    }
    }
