﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class EvenOrOdd
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter a number");
            num = int.Parse(Console.ReadLine());
            if(num <= 0)
            {
                Console.WriteLine("Invalid input");
            }
            else if(num %2 ==0)
            {
                Console.WriteLine("Even Number");
            }
            else
            {
                Console.WriteLine("Odd Number");
            }
        }
    }
}
