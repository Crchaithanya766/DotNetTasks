﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class SignFinder
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter number 1:");
            num = int.Parse(Console.ReadLine());
            if(num <0)
            {
                Console.WriteLine("-1");
            }
            else if(num >0)
            {
                Console.WriteLine("1");
            }
            else
                Console.WriteLine("0");
        }
        }
}
