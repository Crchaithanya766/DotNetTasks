﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class GetMaxDigit
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter a number");
            num = int.Parse(Console.ReadLine());
            int max = num % 10; // 9
            while(max <=num)
            {
                int digit = num % 10;
                if(max <=digit)
                {
                    max = digit;
                }
                num /= 10;
            }
            Console.WriteLine($"Max digit is:{max}");
        }
    }
}
