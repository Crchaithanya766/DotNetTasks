﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class BooleanValue
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter bool1:");
            bool b1 = bool.Parse(Console.ReadLine());
            Console.WriteLine("Enter bool2:");
            bool b2 = bool.Parse(Console.ReadLine());
            Console.WriteLine("Enter bool3:");
            bool b3 = bool.Parse(Console.ReadLine());


            if (b1 == true && b2 == true && b3 == true ? true : false)
            {
                Console.WriteLine("true");
            }
            else if (b1 == true && b2 == true && b3 == false ? true : false)
            {
                Console.WriteLine("true");
            }
            else if (b1 == true && b2 == false && b3 == false ? false : true)
            {
                Console.WriteLine("false");
            }
            else if (b1 == false && b2 == false && b3 == false ? false : true)
            {
                Console.WriteLine("false");
            }
            else if (b1 == true && b2 == false && b3 == true ? false : true)
            {
                Console.WriteLine("false");
            }
        }
    }
}
