﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class Box
    {
        private static void Print_Box(int n,int m)
        {
            int i, j;
            for(i = 1;i <= n;i++)
            {
               
                for(j = 1;j <= m;j++)
                {
                    if(i ==1 || i ==n || j ==1 || j==m)
                        Console.Write($"\t*");
                    else
                        Console.Write("\t");
                }
                Console.WriteLine();
            }
        }
        static void Main(string[] args)
        {
            int rows = 4, colum = 5;
            Print_Box(rows, colum);
        }
    }
}
