﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class Rounder
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("Enter number 1:");
            num = int.Parse(Console.ReadLine());
            if (num < 0 || num == 0 )
            {
                Console.WriteLine("-1");
            }
            else if (num % 2==0)
            {
                //for (int i = 2; i <= num; i++)
                //{
                //    if ((i % 2) == 0)
                //    {
                //        Console.WriteLine($" {i * i}");
                //    }
                //}
                int even = num * num;
                Console.WriteLine($" Square of the even number:{even}");
            }
            else
            {
                int odd = num * num;
                Console.WriteLine($" Square of the odd number:{odd}");
            }          
        }

    }
    
}
