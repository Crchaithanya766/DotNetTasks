﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DotnetTasks
{
    class OddRounder
    {
        static void Main(string[] args)
        {
            int num;
            int mul;
            Console.WriteLine("Enter a number");
            num = int.Parse(Console.ReadLine());

            if (num % 2 != 0 && num > 0)
            {
                for (int i = num; i < 10; i++)
                {
                    mul = i * num;
                    Console.WriteLine($"Multiple Of odd number:{mul}");
                }            
            }
           
            else if (num < 0)
            {
                Console.WriteLine($"{num} -1"); //given number is negative, return -1.
            }
            else if (num == 0)
            {
                Console.WriteLine($" {num} -2"); //given number is zero, return -2.
            }
            else
            {
                Console.WriteLine($"{num} is an even number"); //number is even, return the same number.
            }
        }
    }
}
