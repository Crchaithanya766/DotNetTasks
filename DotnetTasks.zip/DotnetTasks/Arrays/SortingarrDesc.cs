﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Arrays
{
    class SortingarrDesc
    {
        static void Main(string[] args)
        {
            int[] arr = new int[5];
            //int i, j;
            int temp;
            Console.WriteLine("Enter Five Numbers:");
            for (int i = 0; i <= 4; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0;i<=4;i++)
            {
                for(int j=1+1;j<=4;j++)
                {
                    if(arr[i]<arr[j])
                    {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            Console.WriteLine("The following array is the sorted array in descending order");
            for(int i=0;i<=4;i++)
            {
                Console.WriteLine(arr[i]);
            }
    }
    }
}
